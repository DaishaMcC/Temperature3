function convertTemperature(){
        var number= Number(prompt("Enter number here"));

        var option= prompt("Enter the1 option: 1) Fahrenheit, 2) Celsius");

        var fahrenheit=(celsius*9/5)+ 32;
        var celsius=(fahrenheit-32)* 5/9;

        if(option == 1){
            console.log(celsius*9/5)+ 32; // math operation
        }
        

        if(option == 2){
            console.log(fahrenheit-32)* 5/9; // math operation
    }

    //var fahrenheitTemperature = document.getElementById("weather")
    //fahrenheitTemperature.innerHTML +=
}
