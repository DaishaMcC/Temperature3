function getGPA(){
    var studentName= prompt("Enter student name")
    var grade1= Number(prompt("Enter grade1"));
    var grade2= Number(prompt("Enter grade2"));

    var gpa=(grade1+grade2)/2;

    var studentList = document.getElementById("students")
    studentList.InnerHTML += `
    <p>Name: ${studentName}</p>
    <p>Grade 101: ${grade1}</p>
    <p>Grade 102: ${grade2}</p>
    <p>GPA: ${gpa}</p>
`

document.write("GPA: " + gpa);
}